function scrollLeft() {
    const container = document.querySelector('.product-brand');
    container.scrollBy({ left: -300, behavior: 'smooth' });
  }
  
  function scrollRight() {
    const container = document.querySelector('.product-brand');
    container.scrollBy({ left: 300, behavior: 'smooth' });
  }
  